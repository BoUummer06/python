#codding:utf-8
import random


"""exercice 1"""
#devinnette de nombre en methode de binaire

print("nous allons faire un programme sur une devinette de nombre entre 1 à 100 ")
nombre_hazard=random.randint(1,100)
nombre_inscrit=int(input("entrez votre nombre = "))
while nombre_inscrit<1 or nombre_inscrit>100:
    print("\nle nombre doit etre compris entre 1 et 100")
    nombre_inscrit = int(input("entrez un autre nombre = "))

borne_A=1
borne_B=100

essaye = 1

if nombre_inscrit>=1 or nombre_inscrit<=100:
    while nombre_inscrit != nombre_hazard:
        centre = (borne_A+borne_B)// 2
        if nombre_inscrit < nombre_hazard and nombre_hazard <= centre:
            print("tsy ampy fa ampio fogna")
            borne_B = centre
            print(f"le nombre est compris entre {borne_A} et {borne_B}")
            print(" ")
        elif nombre_inscrit < nombre_hazard and nombre_hazard >= centre:
            print("tsy ampy fa ampio fogna")
            borne_A = centre
            print(f"le nombre est compris entre {borne_A} et {borne_B}")
            print(" ")
        elif nombre_inscrit > nombre_hazard and nombre_hazard <= centre:
            print("lasa loatra fa angalao ndreka")
            borne_B = centre
            print(f"le nombre est compris entre {borne_A} et {borne_B}")
            print(" ")
        elif nombre_inscrit < nombre_hazard and nombre_hazard >= centre:
            print("tsy ampy fa ampio fogna")
            borne_A = centre
            print(f"le nombre est compris entre {borne_A} et {borne_B}")
            print(" ")
        nombre_inscrit=int(input("entrez le autre nombre = "))
        essaye += 1

print("AO ZANY!")
print(f"vous l'avez trouver sur {essaye} essaye")









"""exercice 2"""
#identification de nombre parfait

print("à la recherche de nombre parfait ")
nombre = int (input("saisir le nombre = "))
t= []
i=1
j=0
somme = 0

#recherche de diviseur

while i < nombre:
    if nombre%i == 0 :
        t.append(i)
    i+=1

for j in range (len(t)):
    somme += t[j]

if somme == nombre:
    print(f"{nombre} est un nombre parfait")
else:
    print(f"{nombre} n'est pas parfait")






"""exercice 3"""
#simulation de fil d'attente
#tanjogna : anjouter et retirer  des nom dans des listes prioritaires

print("fil d'attente BNI ")
prio = [ "iii"]
normal = [ " "]
p=0
n=0
n_change = 0

n_personne= int (input("le nombre de personne que vous voulez entré = "))
for i in range (n_personne):
    print(f"person {i+1}")
    name= str (input("->"))
    motif = str (input("quel est le motif = "))
    if motif == "Droit" :
        if i < 1:
            prio[p] = name
            p += 1
        else:
            prio.append(name)
            p += 1
    else:
        for j in range (n_personne):
            if j < 1:
                normal[n] = name
                n += 1
            else:
                normal.append(name)
                n += 1
#affichage de resultat
print("priority list :")
for i in range (len(prio)):
    print(i+1,"-",prio[i])
print(" ")
print("list of not priority : ")
for i in range (len(normal)):
    print(i+1,"-",normal[i])
print('\n')

#choix pour effacer
choice = str (input("Do you want to remplace or to erase one element ? = "))
if choice == "Yes" or choice == "yes":
    choice1 = str (input("tap 1 to remplace or erase one element on prio or 2 on normal = "))
    if choice1 == "1":
        choice2 = str(input("tap 1 to change or 2 to remove = "))

        # tanjogna , avoir un entier qui est la position du nombre à remplacer et la valeur du str a remplacer
        if choice2 == "1":
            n_change = int (input("please enter the number of the things to change = "))
            value = str (input("le nouveau remplacement = "))
            n_change -= 1
            prio.pop(n_change)
            prio.insert(n_change , value)  # fonction de remplacage
        elif choice2 == "2":
            n_del = str(input("please enter the number of the things to delete = "))
            n_del -= 1
            prio.pop(n_del)  # fonction pour effacer

    elif choice1 == "2":
         choice2 = str (input("tap 1 to change or 2 to remove = "))
         if choice2 == "1":
             n_change = int(input ("please enter the number of the things to change = "))
             value =  str (input("le nouveau remplacement = "))
             n_change -= 1
             prio.pop(n_change)
             normal.insnert(n_change, value)#fonction de remplacage
         elif choice2 == "2":
             n_del = int (input("please enter the number of the things to delete = "))
             n_del -= 1
             normal.pop(n_del)  # fonction pour effacer
#nouvelle affichage en cas de modification
    print("New priority list :")
    for i in range(len(prio)):
        print(i + 1, "-", prio[i])

    print(" ")
    print("New list of not priority : ")
    for i in range(len(normal)):
        print(i + 1, "-", normal[i])

    print('\n')

else:
    print("BNI thanks you..")












"""exercice 4"""
#verification syntaxique

print("vous pouvez commencer a coder ci-dessous")
correction= str (input())
G=0
D=0
i=1
j= 0
total = 0
parenthese_G = False
parenthese_D = False
for i in range (len(correction)) :
    if correction[i] == "(" :
        parenthese_G = True
    elif correction[i] == ")" :
        parenthese_D = False

if parenthese_D == False and parenthese_G == False:
    print("le code manque de parenthèse ")
for i in range (len(correction)) :
    if correction[i] == "(" :
        G +=1
    elif correction[i] == ")" :
        D += 1

total = G + D
print( total )
if total%2 != 0 :
    print ("il y a un probleme au niveau du parenthèse , veuillez rectifier le code")
else:
    print("code correcte !")








"""exercice 5"""
#programme pour un simulation d'avion

temps= [ "Ensoleillé",  "Nuageux" , "Orageux", "Pluvieux"]
position= ["près de la piste de décollage", "mi-chemin", "en voie d'atterissage"]

condition= str (input( "saisir le temps ="))

while condition == temps [2] or condition == temps[3]:
    print("le vole est reporter..")
    condition = str(input( "saisir le temps ="))
print("decollage iminante ..")

situation= str (input("decrivez votre position actuel ="))

while situation != position[2]:
    condition = str(input("saisir le temps = "))
    
    if condition == temps [2] or condition == temps[3] and situation == position[0]:
        print(" Retour au piste de decollage ")
    elif condition == temps [0] or condition == temps [1] and situation == position[0]:
        print("permission de continuer , rapport à mi-chemin ")
    elif condition == temps [0] or condition == temps [1] and situation == position[1]:
        print("permission de continuer , rapport à l'arrivé ")
    elif condition == temps [2] or condition == temps[3] and situation == position[1]:
        print(" atterissez au point le plus proche ")
    situation = str(input("decrivez votre position actuel ="))
    
print("atterissage imminante..")






"""exercice 6"""
#jeu de rôle textuelle , genre hoe manao pro manome choix anle participant
#while gere les tours, for proposent differentes option et if determinent les conséquence du choix

print("jeu de role ( 2 à 3 personne)")
n = int (input("nombre de joueurs = "))
tableau = ["hhhhh", "hh", "jjjj"]
tour= 0
indice_joueur = 1
for i in range (n):
    print("entrez le nom du joueur ", indice_joueur)
    participant = str (input ("->"))
    tableau[i]= participant
    indice_joueur += 1
print("\n")

while tour <2:
    for i in range (n):
        if i == 0:
            print("question pour le joueur ", tableau[i])
            print("choisir entre 1 et 2")
            print("Raha toa ka tsy hay ny lesona , ny hevitra tena mety")
            print("\t1-Ianarako ny lesona")
            print("\t2-Miala mianatra")
            choix = str (input("votre choix = "))
            if choix == "1":
                print("Marina fa tsara ny mianatra fa mety² kokoa ny miala mianatra")
            elif choix == "2":
                print("marina zany rall ah!!")
            print("\n")

        elif i == n-1 :
            print("question pour le joueur ", tableau[i])
            print("choisir entre 1 et 2")
            print("Reraka ah zany")
            print("\t1-aleo atory")
            print("\t2-hamono tena")
            choix = str(input("votre choix = "))
            if choix == "1":
                print("C'est bien")
            elif choix == "2":
                print("mety ka!!")
            print("\n")

        else:
            print("question pour le joueur ", tableau[i])
            print("choisir entre 1 et 2")
            print("Very aty antanin'olo")
            print("\t1-midepra ")
            print("\t2-hamono tena")
            choix = str(input("votre choix = "))
            if choix == "1":
                print("mety ny midepra fa ny mitomany ihany tsy azo atao nama ah")
            elif choix == "2":
                print("hevitra koa!!")
            print("\n")
    tour += 1
    







"""exercice 7""" #any am daniel


"""exercice 8"""



"""exercice 9"""# daniel
#calcule de l'exponentielle



"""ec=xercice 10"""
#symulation d'ecosysteme
